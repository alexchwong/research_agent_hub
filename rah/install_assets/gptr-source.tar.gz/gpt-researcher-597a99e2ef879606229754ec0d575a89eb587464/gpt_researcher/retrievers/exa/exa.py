import os
from ..utils import check_pkg


class ExaSearch:
    """
    Exa API Retriever
    """

    def __init__(self, query, query_domains=None):
        """
        Initializes the ExaSearch object.
        Args:
            query: The search query.
        """
        # This validation is necessary since exa_py is optional
        check_pkg("exa_py")
        from exa_py import Exa
        self.query = query
        self.api_key = self._retrieve_api_key()
        self.client = Exa(api_key=self.api_key)
        self.query_domains = query_domains or None

    def _retrieve_api_key(self):
        """
        Retrieves the Exa API key from environment variables.
        Returns:
            The API key.
        Raises:
            Exception: If the API key is not found.
        """
        try:
            api_key = os.environ["EXA_API_KEY"]
        except KeyError:
            raise Exception(
                "Exa API key not found. Please set the EXA_API_KEY environment variable. "
                "You can obtain your key from https://exa.ai/"
            )
        return api_key

    def search(
        self, max_results=10, use_autoprompt=False, search_type="neural", **filters
    ):
        """
        Searches the query using the Exa API.
        Args:
            max_results: The maximum number of results to return.
            use_autoprompt: Whether to use autoprompting.
            search_type: The type of search (e.g., "neural", "keyword").
            **filters: Additional filters (e.g., date range, domains).
        Returns:
            A list of search results.
        """
        try:
            results = self.client.search(
                self.query,
                type=search_type,
                use_autoprompt=use_autoprompt,
                num_results=max_results,
                include_domains=self.query_domains,
                **filters
            )
        except Exception as e:
            print(f"Error: {e}. Failed fetching sources from Exa. Empty response.")
            return []

        search_response = []
        rows = getattr(results, "results", None) or []
        if not isinstance(rows, list):
            return []
        for result in rows:
            href = getattr(result, "url", None)
            if not href:
                continue
            body = getattr(result, "text", None) or getattr(result, "summary", None) or ""
            search_response.append({"href": href, "body": body})
        return search_response

    def find_similar(self, url, exclude_source_domain=False, **filters):
        """
        Finds similar documents to the provided URL using the Exa API.
        Args:
            url: The URL to find similar documents for.
            exclude_source_domain: Whether to exclude the source domain in the results.
            **filters: Additional filters.
        Returns:
            A list of similar documents.
        """
        # Mirror search()'s hardening: any failure here previously propagated
        # into the research run, and a client that returned ``None`` instead of
        # a results object raised AttributeError on the ``.results`` access.
        try:
            results = self.client.find_similar(
                url, exclude_source_domain=exclude_source_domain, **filters
            )
        except Exception as e:
            print(
                f"Error: {e}. Failed fetching similar sources from Exa. Empty response."
            )
            return []

        similar_response = []
        rows = getattr(results, "results", None) or []
        if not isinstance(rows, list):
            return []
        for result in rows:
            href = getattr(result, "url", None)
            if not href:
                continue
            body = getattr(result, "text", None) or getattr(result, "summary", None) or ""
            similar_response.append({"href": href, "body": body})
        return similar_response

    def get_contents(self, ids, **options):
        """
        Retrieves the contents of the specified IDs using the Exa API.
        Args:
            ids: The IDs of the documents to retrieve.
            **options: Additional options for content retrieval.
        Returns:
            A list of document contents.
        """
        try:
            results = self.client.get_contents(ids, **options)
        except Exception as e:
            print(
                f"Error: {e}. Failed fetching contents from Exa. Empty response."
            )
            return []

        contents_response = []
        rows = getattr(results, "results", None) or []
        if not isinstance(rows, list):
            return []
        for result in rows:
            result_id = getattr(result, "id", None)
            if result_id is None:
                continue
            content = getattr(result, "text", None) or ""
            contents_response.append({"id": result_id, "content": content})
        return contents_response
